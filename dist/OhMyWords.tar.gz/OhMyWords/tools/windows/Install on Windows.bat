@echo off
rem Double-click to install (or update) Oh My WORDS! on this PC.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
